# aecii's Tools
**Version:** 1.4.0  
**Blender:** 4.5 and above  
**Location:** View3D > N Panel > aecii's tools

---

## Tools included

### Bone & Vertex Tools
| Tool | What it does |
|------|-------------|
| **Remove Unused Bones** | Deletes bones from an armature that have no weighted vertices on any skinned mesh |
| **Remove Empty Vertex Groups** | Removes vertex groups with zero weights from the active mesh |
| **Remove Empty Blendshapes** | Removes shape keys that are identical to their relative key (no actual deformation) |

### Shape Key Search
Live search panel at the bottom of the N panel tab. Select a mesh that has shape keys, type any part of a shape key name, and matching results appear instantly. Each result has an inline value slider so you can adjust it without leaving the panel. Clicking a result makes it the active shape key.

---

## Settings

| Setting | Effect |
|---------|--------|
| **Keep Non-Deform Bones** | Bones flagged as non-deform are spared when removing unused bones |
| **Keep Parent Chains** | Any parent bones of used bones are also kept, preserving hierarchy |
| **Verbose Logging** | Prints extra info to the system console and info bar while tools run |

---

## Installation

1. Open Blender (4.5 or later).
2. Go to **Edit → Preferences → Add-ons**.
3. Click **Install…** and select `aecii_tools_v1.4.0.zip`.
4. Tick the checkbox next to **aecii's Tools**.
5. Open the **N panel** in the 3D Viewport (press **N**) and click the **aecii's tools** tab.

---

## Changelog

### v1.4.0
- Added **Shape Key Search** panel — filter and edit shape keys by name directly in the N panel

### v1.3.0
- Initial release with bone cleanup, vertex group cleanup, and blendshape cleanup
